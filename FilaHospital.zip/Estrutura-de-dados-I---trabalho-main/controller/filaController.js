const filaAtendimento = new Fila(5);

function adicionarElemento() {
  const inputNome = document.getElementById("txtnovoNome");
  const inputCpf = document.getElementById("txtnovoCPF");
  
  if (!inputNome.value || !inputCpf.value) {
      alert("Por favor, preencha o Nome e o CPF!");
      return;
  }

  const novoAtendimento = new Atendimento(
      inputNome.value,
      inputCpf.value,
      obterDataAtual(),
      obterHoraAtual()
  );

  if (filaAtendimento.enqueue(novoAtendimento)) {
      atualizarVisaoFila();
      inputNome.value = "";
      inputCpf.value = "";
      inputNome.focus();
  } else { 
      alert("Fila cheia!");
  }
}

function atualizarVisaoFila() {
  const listaFila = document.getElementById("listFila");
  listaFila.innerHTML = "";
  
  for (let item of filaAtendimento) {
      const listItem = document.createElement("li");
      listItem.textContent = item.toString();
      listaFila.appendChild(listItem);
  }
}

function removerElemento() {
  const removido = filaAtendimento.dequeue();
  const painelMensagem = document.getElementById("mensagem-remocao");
  
  if (!removido) {
      alert("Fila vazia");
      return;
  }
  
  alert("Atendido: " + removido.nome);
  atualizarVisaoFila();
  
  painelMensagem.innerHTML = `Próximo atendimento: ${removido.nome} | Tempo de espera: ${calcularDiferencaHoras(removido.hora, obterHoraAtual())}`;
  localStorage.setItem('ultimoAtendimento', removido.nome);
}

function buscarElemento() {
  const buscaCpf = document.getElementById("txtnovoCPF").value;
  const buscaNome = document.getElementById("txtnovoNome").value;
  let encontrado = false;
  
  for (let atendimento of filaAtendimento) {
      if (buscaCpf === atendimento.cpf || buscaNome === atendimento.nome) {
          alert("Encontrado na fila: " + atendimento.toString());
          encontrado = true;
          break;
      }
  }
  
  if (!encontrado) {
      alert("Pessoa não está na fila");
  }
}