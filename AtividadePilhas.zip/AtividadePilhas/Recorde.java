import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Recorde {
    private LocalDate data;
    private double tempo;
    private String nome;

    // Construtor
    public Recorde(LocalDate data, double tempo, String nome) {
        this.data = data;
        this.tempo = tempo;
        this.nome = nome;
    }

    // Getters
    public LocalDate getData() {
        return data;
    }

    public double getTempo() {
        return tempo;
    }

    public String getNome() {
        return nome;
    }

    // Método toString
    @Override
    public String toString() {
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return String.format("Atleta: %s | Tempo: %.2fs | Data: %s", 
                             nome, tempo, data.format(formatador));
    }
}