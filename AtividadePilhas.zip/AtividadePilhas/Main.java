import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatadorData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        System.out.print("Defina o tamanho inicial da pilha de recordes: ");
        int tamanhoInicial = scanner.nextInt();
        scanner.nextLine(); // Limpar o buffer do teclado

        PilhaDeRecordes pilha = new PilhaDeRecordes(tamanhoInicial);
        int opcao = 0;

        while (opcao != 5) {
            System.out.println("\n=================================");
            System.out.println("       PILHA DE RECORDES");
            System.out.println("=================================");
            System.out.println("1. Inserir novo recorde");
            System.out.println("2. Consultar recorde atual (Topo)");
            System.out.println("3. Remover recorde do topo");
            System.out.println("4. Listar todos os recordes");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer

            switch (opcao) {
                case 1:
                    System.out.print("Nome do atleta: ");
                    String nome = scanner.nextLine();
                    
                    System.out.print("Tempo do recorde (ex: 9.58): ");
                    double tempo = scanner.nextDouble();
                    scanner.nextLine(); 
                    
                    System.out.print("Data do recorde (dd/MM/yyyy): ");
                    String dataStr = scanner.nextLine();
                    LocalDate data = LocalDate.parse(dataStr, formatadorData);

                    Recorde novoRecorde = new Recorde(data, tempo, nome);
                    
                    if (pilha.inserir(novoRecorde)) {
                        System.out.println("\n✅ Recorde inserido com sucesso!");
                    } else {
                        System.out.println("\n❌ Erro: O tempo de " + tempo + 
                                           "s não supera o recorde atual do topo.");
                    }
                    break;

                case 2:
                    Recorde topo = pilha.consultarTopo();
                    if (topo != null) {
                        System.out.println("\n🏆 Recorde Atual do Topo:");
                        System.out.println(topo);
                    } else {
                        System.out.println("\n⚠️ A pilha está vazia.");
                    }
                    break;

                case 3:
                    Recorde removido = pilha.remover();
                    if (removido != null) {
                        System.out.println("\n🗑️ Recorde removido com sucesso: " + removido);
                    } else {
                        System.out.println("\n⚠️ A pilha já está vazia, nada para remover.");
                    }
                    break;

                case 4:
                    System.out.println("\n--- Histórico de Recordes (do mais recente ao mais antigo) ---");
                    pilha.listarRecordes();
                    break;

                case 5:
                    System.out.println("\nEncerrando o programa...");
                    break;

                default:
                    System.out.println("\nOpção inválida! Tente novamente.");
            }
        }
        scanner.close();
    }
}
