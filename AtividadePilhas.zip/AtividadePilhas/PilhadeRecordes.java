public class PilhaDeRecordes {
    private Recorde[] elementos;
    private int topo;

    public PilhaDeRecordes(int tamanhoInicial) {
        elementos = new Recorde[tamanhoInicial];
        topo = -1; // -1 indica que a pilha está vazia
    }

    // Verifica se a pilha está vazia
    public boolean isVazia() {
        return topo == -1;
    }

    // Consulta o elemento do topo sem removê-lo
    public Recorde consultarTopo() {
        if (isVazia()) {
            return null;
        }
        return elementos[topo];
    }

    // Método de resize automático
    private void redimensionar() {
        System.out.println("\n[Aviso] Limite atingido! Redimensionando a pilha automaticamente...");
        Recorde[] novoArray = new Recorde[elementos.length * 2]; // Dobra a capacidade
        System.arraycopy(elementos, 0, novoArray, 0, elementos.length);
        elementos = novoArray;
    }

    // Insere um novo recorde na pilha (Push)
    public boolean inserir(Recorde novoRecorde) {
        if (!isVazia()) {
            // Regra: O tempo do novo recorde DEVE ser MENOR que o atual
            if (novoRecorde.getTempo() >= consultarTopo().getTempo()) {
                return false; 
            }
        }
        
        // Verifica se precisa de resize
        if (topo == elementos.length - 1) {
            redimensionar();
        }
        
        elementos[++topo] = novoRecorde;
        return true;
    }

    // Remove o elemento do topo (Pop)
    public Recorde remover() {
        if (isVazia()) {
            return null;
        }
        Recorde removido = elementos[topo];
        elementos[topo] = null; // Libera a referência de memória
        topo--;
        return removido;
    }

    // Lista todos os recordes (do topo para a base)
    public void listarRecordes() {
        if (isVazia()) {
            System.out.println("A pilha de recordes está vazia.");
            return;
        }
        for (int i = topo; i >= 0; i--) {
            System.out.println(elementos[i]);
        }
    }
}